======================================================================
BRAND SIGNAGES - BULK CUSTOM PAGES UPLOAD GUIDE
======================================================================

FOLDER STRUCTURE INSIDE YOUR ZIP:
----------------------------------
my_bulk_pages.zip
├── surat_index.php             <-- Your page files (.php or .html)
├── hyderabad_index.php
├── sample_custom_page.php
└── images/                     <-- All page images here
    ├── sample-banner.webp
    └── sample-showcase.webp

RULES & BEST PRACTICES:
-----------------------
1. NO HEADER & NO FOOTER:
   - Do NOT include <header>, <footer>, <html>, or <body> tags.
   - The website header and footer are automatically added by the site layout.

2. IMAGE PATHS:
   - Place all your page images inside the "images/" folder of this ZIP.
   - Reference images in your HTML using relative paths like:
     <img src="images/sample-showcase.webp">
     or
     <div style="background-image: url('images/sample-banner.webp');">
   - During bulk upload, the system automatically saves the images into the website
     assets directory and links them correctly.

3. PAGE TITLE & SLUG:
   - You can define optional metadata at the top of your page file:
     <!--
     Title: Premium Sign Board Manufacturers in Surat
     Slug: sign-board-manufacturers-in-surat
     CSS: (Optional CSS file name)
     -->
   - If omitted, the title and slug will be automatically detected from <h1> or the file name.

4. UPLOAD:
   - Go to Admin Panel -> All Custom Pages -> "Bulk Upload Pages"
   - Select your .zip archive and click "Start Bulk Upload".
======================================================================